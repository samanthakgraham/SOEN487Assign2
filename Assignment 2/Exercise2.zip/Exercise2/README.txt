SOEN487 Winter 2017 Assignment 2 Excercise 2
Submitted by Samantha Graham #21120689

To run:

1. Open the TemperatureJSClient project in Netbeans.
2. Click Run (F6). Project will open in your default browser.