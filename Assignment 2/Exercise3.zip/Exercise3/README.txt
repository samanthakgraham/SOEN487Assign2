SOEN487 Winter 2017 Assignment 2 Excercise 3
Submitted by Samantha Graham #21120689

To run:

1. Open the DeliciousClient project in Netbeans.
2. Click Run (F6). Project will open in your default browser.
3. Click on either of the buttons. The bookmarks will display as links under the clicked button. Links open in a new tab.